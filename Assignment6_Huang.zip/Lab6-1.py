# ---------------------------------------------------------------------------------------------#
# Title: Lab6-1 Working with functions
# Description: 1)    Create a function that prints the Sum, Difference, Product, and Quotient
#                   of two numbers.
# Dev: Cindy Huang
# Date: 11/19/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#

# -- data code --
intNumber1 = None   # first argument
intNumber2 = None   # second argument
Result = []         # empty list that will be replaced with calculated results


# -- Processing the data --
# 1) Define a function to do sum, difference, product and quotient
def BasicMath(intNumber1,intNumber2):
    intSum = intNumber1 + intNumber2
    intDiff = abs(intNumber1 - intNumber2)
    intProd = intNumber1 * intNumber2
    fltQuo = intNumber1 / intNumber2

    #print out results
    print("The sum of these two numbers is :", intSum)
    print("The difference of these two numbers is :", intDiff)
    print("The product of these two numbers is :", intProd)
    print("The quotient of these two numbers is :", fltQuo)

#-- Presentation (Input/Output) --#
# get user input
intNumber1 = int(input("Please enter an integer: "))
intNumber2 = int(input("please another integer: "))
# send program output
BasicMath(intNumber1, intNumber2)
