# ---------------------------------------------------------------------------------------------#
# Title: Lab6-2: Working with returned lists
# Description: 1)   Create a function that returns a list of the Sum, Difference, Product,
#                   and Quotient of two numbers.
#              2)	Display the results to the user.
#              3)	Divide you program into data, processing, and presentation sections.
# Dev: Cindy Huang
# Date: 11/19/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#

# -- data code --
intNumber1 = None   # first argument
intNumber2 = None   # second argument
Result = []         # empty list that will be replaced with calculated results


# -- Processing the data --
# 1) Define a function to do sum, difference, product and quotient
def BasicMath(intNumber1,intNumber2):
    intSum = intNumber1 + intNumber2
    intDiff = abs(intNumber1 - intNumber2)
    intProd = intNumber1 * intNumber2
    fltQuo = intNumber1 / intNumber2

    return [intSum, intDiff, intProd, fltQuo]

#-- Presentation (Input/Output) --
# get user input
intNumber1 = int(input("Please enter an integer: "))
intNumber2 = int(input("please another integer: "))

# call the function
Result=BasicMath(intNumber1,intNumber2)

# 2) display the results to the user
print("The sum of the two numbers is: ", Result[0])
print("The difference of the two numbers is: ", Result[1])
print("The product of the two numbers is: ", Result[2])
print("The quotient of the two numbers is: ", Result[3])