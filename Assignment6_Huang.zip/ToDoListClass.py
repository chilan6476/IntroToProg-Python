#---------------------------------------------------------------------------------------------#
# Title: Assignment 6
# Description: 1.   Create a text file called Todotxt using the following data:
#                    Clean House,low
#                    Pay Bills,high
#              2.	When the program starts, load each row of data from the ToDotxt text file
#                   into a Python dictionary. (The data will be stored like a row in a table.)
#                   Tip: You can use a for loop to read a single line of text from the file and
#                       then place the data into a new dictionary object.
#              3.	After you get the data in a Python dictionary, Add the new dictionary “row”
#                   into a Python list object (now the data will be managed as a table).
#              4.	Display the contents of the List to the user.
#              5.	Allow the user to Add or Remove tasks from the list using numbered choices.
#                   Something like this would work:
#                   Menu of Options
#                   1) Show current data
#                   2) Add a new item.
#                   3) Remove an existing item.
#                   4) Save Data to File
#                   5) Exit Program
#              6.	Save the data from the table into the Todotxt file when the program exits.
# Dev: Cindy Huang
# Date: 11/20/2018
# Rev History: none
#---------------------------------------------------------------------------------------------#

# -- data code --#
objFileName = "/Users/chilan6476/Documents/_PythonClass/Assignment06/ToDo.txt"
strChoice = "Which option would you like to perform? [1-4] - "

#-- Processing --#
# Define a class that contains 7 methods
class ToDoList(object):

    # Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
    @staticmethod
    def ReadToDoFile(strFileName):
        objFile = open(strFileName, "r")
        # strData = A row of text data from the file
        strData = objFile.readlines()
        # lstTable = A dictionary that acts as a 'table' of rows (null to start with)
        lstTable = list()
        for i in strData:
            # dicRow = A row of data separated into elements of a dictionary {Task,Priority}
            dicRow = {"Task": i[0:i.find(",")], "Priority": i[i.find(",") + 1:-1]}
            lstTable.append(dicRow)
        return lstTable

    # Step 2
    # Display a menu of choices to the user
    @staticmethod
    def DisplayMenu():
        strMenu = "Menu of Options \n" \
                  "1) Show current data" + "\n" \
                  "2) Add a new item" + "\n" \
                  "3) Remove an existing item" + "\n" \
                  "4) Save Data to File" + "\n" \
                  "5) Exit Program" + "\n"
        print(strMenu)

    # Step 3
    # Display all todo items to user
    def DisplayToDoList(lstTable):
        print("\n--------------- Current ToDo items are ---------------")
        for row in lstTable:
            print(row["Task"] + " (" + row["Priority"] + ")")
        print("------------------------------------------------------\n")

    # Step 4
    # Add a new item to the list/Table
    def AddToDo(lstTable):
        strNewTask = input("\nWhat is the new Task? ")
        strNewPriority = input("What is the priority? [low/high] ")
        dicRowNew = {"Task": strNewTask, "Priority": strNewPriority}
        lstTable.append(dicRowNew)

        print("\nAn new has has been added \n\n"
              "--------------- Current ToDo items are ---------------")
        for row in lstTable:
            print(row["Task"] + " (" + row["Priority"] + ")")
        print("------------------------------------------------------\n")

        return lstTable

    # Step 5
    # Remove a new item to the list/Tables
    def RemoveToDo(lstTable):
        booTaskExist=False
        strRemovedTask = input("\nWhich task would you like to remove? ")
        for row in lstTable:
            if (row["Task"].lower() == strRemovedTask.lower()):
                lstTable.remove(row)
                print("\nThe task has been removed \n")
                booTaskExist = True
        if booTaskExist == False:
            print("\nThe task is not in the ToDo list\n")
        print("--------------- Current ToDo items are ---------------")
        for row in lstTable:
            print(row["Task"] + " (" + row["Priority"] + ")")
        print("------------------------------------------------------\n")

        return lstTable

    # Step 6
    # Save tasks to the ToDo.txt file
    def SaveToDo(lstTable,strFileName):
        while True:
            strUserFile = input("Would you like to save the ToDo list to a file? [y/n] ")
            if strUserFile == "y":
                strTodoList = open(strFileName, "w")
                for row in lstTable:
                    strTodoList.write(row["Task"] + "," + row["Priority"] + "\n")
                print("\nData saved to file.\n")
                strTodoList.close()
                break
            elif strUserFile == "n":
                print("\nData was not saved to file.\n")
                break

    # Step 7
    # Exit program
    def ExitToDo():
        exit()



#-- Input/Output --#1
lstTable = ToDoList.ReadToDoFile(objFileName)

while True:
    # User can see a Menu (Step 2)
    ToDoList.DisplayMenu()
    # strChoice = Capture the user option selection
    strUserChoice = input(strChoice)

    # User can see data (Step 3)
    if strUserChoice == "1":
        ToDoList.DisplayToDoList(lstTable)
    # User can delete data(Step 4)
    elif strUserChoice == "2":
        ToDoList.AddToDo(lstTable)
    # User can insert data(Step 5)
    elif strUserChoice == "3":
        ToDoList.RemoveToDo(lstTable)
    # User can save to file (Step 6)
    elif strUserChoice == "4":
        ToDoList.SaveToDo(lstTable,objFileName)
    elif strUserChoice == "5":
        ToDoList.ExitToDo()
