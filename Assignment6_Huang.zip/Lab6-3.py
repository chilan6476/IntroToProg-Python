# ---------------------------------------------------------------------------------------------#
# Title: Lab6-3:  Working with classes
# Description: 1)	Create a class with (4) Methods, have them return a Sum, Difference,
#                   Product, and Quotient of two numbers.
#              2)	Name the class MathProcessor
#              3)	Name the methods AddValues, SubtractValues, MultiplyValues, DivideValues.
#              4)	Display the results to the user by calling each method.
# Dev: Cindy Huang
# Date: 11/20/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#

# -- data code --
intNumber1 = None   # first argument
intNumber2 = None   # first argument

# -- Processing the data --
# 1) Define a class that contains 4 methods: sum, difference, product and quotient
# 2) name the class MathProcessor
class MathProcessor(object):

    # 3) method 1 - AddValues
    @staticmethod
    def AddValues(intNumber1, intNumber2):
        return intNumber1 + intNumber2

    # 3) method 2 - SubtractValues
    @staticmethod
    def SubtractValues(intNumber1,intNumber2):
        return intNumber1 - intNumber2


    # 3) method 3 - MultiplyValues
    @staticmethod
    def MultiplyValues(intNumber1,intNumber2):
        return intNumber1 * intNumber2


    # 3) method 4 DivideValues
    @staticmethod
    def DivideValues(intNumber1,intNumber2):
        return intNumber1 / intNumber2

#-- Presentation (Input/Output) --
# get user input
intNumber1 = int(input("Please enter an integer: "))
intNumber2 = int(input("please another integer: "))


# 4) display the results to the user by calling each method
print("The sum of the two numbers is: ", MathProcessor.AddValues(intNumber1,intNumber2))
print("The difference of the two numbers is: ", MathProcessor.SubtractValues(intNumber1,intNumber2))
print("The product of the two numbers is: ", MathProcessor.MultiplyValues(intNumber1,intNumber2))
print("The quotient of the two numbers is: ", MathProcessor.DivideValues(intNumber1,intNumber2))