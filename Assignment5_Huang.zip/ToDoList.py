#---------------------------------------------------------------------------------------------#
# Title: Assignment 5
# Description: 1.   Create a text file called Todotxt using the following data:
#                    Clean House,low
#                    Pay Bills,high
#              2.	When the program starts, load each row of data from the ToDotxt text file
#                   into a Python dictionary. (The data will be stored like a row in a table.)
#                   Tip: You can use a for loop to read a single line of text from the file and
#                       then place the data into a new dictionary object.
#              3.	After you get the data in a Python dictionary, Add the new dictionary “row”
#                   into a Python list object (now the data will be managed as a table).
#              4.	Display the contents of the List to the user.
#              5.	Allow the user to Add or Remove tasks from the list using numbered choices.
#                   Something like this would work:
#                   Menu of Options
#                   1) Show current data
#                   2) Add a new item.
#                   3) Remove an existing item.
#                   4) Save Data to File
#                   5) Exit Program
#              6.	Save the data from the table into the Todotxt file when the program exits.
# Dev: Cindy Huang
# Date: 11/16/2018
# Rev History: none
#---------------------------------------------------------------------------------------------#
# -- Data --#
# declare variables and constants
objFileName = "/Users/chilan6476/Documents/_PythonClass/Assignment05/ToDo.txt"

# use try-except to ensure the file exists
try:
    # -- Data --#
    # declare variables and constants

    # Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
    # objFile = An object that represents a file
    objFile = open(objFileName, "r")

    # strData = A row of text data from the file
    strData = objFile.readlines()

    # lstTable = A dictionary that acts as a 'table' of rows (null to start with)
    lstTable = list()
    for i in strData:
        # dicRow = A row of data separated into elements of a dictionary {Task,Priority}
        dicRow = {"Task": i[0:i.find(",")], "Priority": i[i.find(",") + 1:-1]}
        lstTable.append(dicRow)

    # strMenu = A menu of user options
    strMenu = "Menu of Options \n" \
               "1) Show current data" + "\n" \
               "2) Add a new item" + "\n" \
               "3) Remove an existing item" + "\n" \
               "4) Save Data to File" + "\n" \
               "5) Exit Program" + "\n"

    # strChoice = Capture the user option selection
    strChoice = "Which option would you like to perform? [1-4] - "

    # booTaskExist = a flag to check if the task is in the ToDo list
    booTaskExist = False

    while True:
        # -- Input/Output --#
        # Step 2
        # Display a menu of choices to the user
        print(strMenu)
        strUserChoice = input(strChoice)
        booTaskExist = False

        # Step 3
        # Display all todo items to user
        if strUserChoice == "1":
            # -- Input/Output --#
            print("\n--------------- Current ToDo items are ---------------")
            for row in lstTable:
                print(row["Task"] + " (" + row["Priority"] + ")")
            print("------------------------------------------------------\n")

        # Step 4
        # Add a new item to the list/Table
        elif strUserChoice == "2":
            # -- Input/Output --#
            strNewTask = input("\nWhat is the new Task? ")
            strNewPriority = input("What is the priority? [low/high] ")
            dicRowNew={"Task":strNewTask, "Priority":strNewPriority}
            lstTable.append(dicRowNew)

            print("\nAn new has has been added \n\n"
                  "--------------- Current ToDo items are ---------------")
            for row in lstTable:
                print(row["Task"] + " (" + row["Priority"] + ")")
            print("------------------------------------------------------\n")

        # Step 5
        # Remove a new item to the list/Table
        elif strUserChoice == "3":
            # -- Input/Output --#
            strRemovedTask = input("\nWhich task would you like to remove? ")
            for row in lstTable:
                if(row["Task"].lower()==strRemovedTask.lower()):
                    lstTable.remove(row)
                    print("\nThe task has been removed \n")
                    booTaskExist=True
            if booTaskExist==False:
                print("\nThe task is not in the ToDo list\n")
            print("--------------- Current ToDo items are ---------------")
            for row in lstTable:
                print(row["Task"] + " (" + row["Priority"] + ")")
            print("------------------------------------------------------\n")

        # Step 6
        # Save tasks to the ToDo.txt file
        elif strUserChoice == "4":
            # -- Input/Output --#
            while True:
                strUserFile = input("Would you like to save the ToDo list to a file? [y/n] ")
                if strUserFile == "y":
                    strTodoList= open("/Users/chilan6476/Documents/_PythonClass/Assignment05/ToDo.txt", "w")
                    for row in lstTable:
                        strTodoList.write(row["Task"] + "," + row["Priority"] + "\n")
                    print("\nData saved to file.\n")
                    strTodoList.close()
                    break
                elif strUserFile == "n":
                    print("\nData was not saved to file.\n")
                    break

        # Step 7
        # Exit program
        elif strUserChoice == "5":
            break

        # check if the user did not select any of the options
        else:
            print("\nplease choose one of the options [1-5] \n")

except:
    # print if the file doesn't exist
    print("The file cannot be found")