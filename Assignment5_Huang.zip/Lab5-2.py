#---------------------------------------------------------------------------------------------#
#Title: Lab5-2
#Description: 1)	Create an application that uses a dictionary to hold the following data:
#                   Id	Name	Email
#                   1	Bob Smith	BSmith@Hotmail.com
#                   2	Sue Jones	SueJ@Yahoo.com
#                   3	Joe James	JoeJames@Gmail.com
#             2)	Add code that lets users appends a new row of data.
#             3)	Add a loop that lets the user keep adding rows.
#             4)	Ask the user if they want to save the data to a file when they exit the loop.
#             5)	Save the data to a file if they say 'yes'
#Dev: Cindy Huang
#Date: 11/13/2018
#Rev History: none
#---------------------------------------------------------------------------------------------#



#1) the dictionary of data
dicRow1={"ID":1, "Name":"Bob Smith", "Email":"BSmith@Hotmail.com"}
dicRow2={"ID":2, "Name":"Sue Jones", "Email":"SueJ@Yahoo.com"}
dicRow3={"ID":3, "Name":"Joe James", "Email":"JoeJames@Gmail.com"}

intID=dicRow3["ID"]

#1) create a nested list for a table
lstTable=[dicRow1,dicRow2,dicRow3]

#3)	Add a loop that lets the user keep adding rows.
while True:
    # ask if the user wants to exit or add a new row of data
    UserInput=input("please enter 'exit' or select Enter Key to add new row ")

    # check if the user enters exit
    if UserInput.lower() == "exit":
        # write the lstTable to the file then break out of the loop
        while True:
            # 4) Ask the user if they want to save the data to a file when they exit the loop.
            UserSave = input("Would you like to save the table to Lab52table.txt? [y/n] ")
            if UserSave.lower() == "y":
                # 5) Save the data to a file if they say 'yes'
                lab52Table= open("/Users/chilan6476/Documents/_PythonClass/Assignment05/Lab52table.txt", "w")
                lab52Table.write("ID" + "\t\t" + "Name" + "\t\t\t" + "Email" + "\n")
                for row in lstTable:
                    lab52Table.write(str(row["ID"])+"\t\t"+row["Name"]+"\t\t"+row["Email"]+"\n")
                # closer the file
                lab52Table.close()
                break

            elif UserSave.lower() == "n":
                break
        break
    # check if the user select the enter key
    elif not UserInput:

        # ask for a Name
        intID = intID + 1
        strName = input("please enter name: ")
        # ask for an Email
        strEmail = input ("please enter an email: ")
        # save the item and estimated value as a dicNewRow
        dicNewRow = {"ID":intID, "Name":strName,"Email":strEmail}
        # add the new row
        lstTable.append(dicNewRow)


