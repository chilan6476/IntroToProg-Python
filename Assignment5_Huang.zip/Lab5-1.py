#---------------------------------------------------------------------------------------------#
#Title: Lab5-1
#Description: 1)	Create an application that uses a list to hold the following data:
#                   Id	Name	Email
#                   1	Bob Smith	BSmith@Hotmail.com
#                   2	Sue Jones	SueJ@Yahoo.com
#                   3	Joe James	JoeJames@Gmail.com
#             2)	Add code that lets users appends a new row of data.
#             3)	Add a loop that lets the user keep adding rows.
#             4)	Ask the user if they want to save the data to a file when they exit the loop.
#             5)	Save the data to a file if they say 'yes'
#Dev: Cindy Huang
#Date: 11/12/2018
#Rev History: none
#---------------------------------------------------------------------------------------------#



#1) the lists of data
lstHeader=["ID","Name","\t"+" Email"]
lstRow1=[1, "Bob Smith", "BSmith@Hotmail.com"]
lstRow2=[2, "Sue Jones", "SueJ@Yahoo.com"]
lstRow3=[3, "Joe James", "JoeJames@Gmail.com"]

intID=lstRow3[0]

#1) create a nested list for a table
lstTable=[lstHeader,lstRow1,lstRow2,lstRow3]

#3)	Add a loop that lets the user keep adding rows.
while True:
    # ask if the user wants to exit or add a new row of data
    UserInput=input("please enter 'exit' or select Enter Key to add new row ")

    # check if the user enters exit
    if UserInput.lower() == "exit":
        # write the lstTable to the file then break out of the loop
        while True:
            # 4) Ask the user if they want to save the data to a file when they exit the loop.
            UserSave = input("Would you like to save the table to Lab51table.txt? [y/n] ")
            if UserSave.lower() == "y":
                # 5) Save the data to a file if they say 'yes'
                lab51Table= open("/Users/chilan6476/Documents/_PythonClass/Assignment05/Lab51table.txt", "w")
                for row in lstTable:
                    lab51Table.write(str(row[0])+"\t\t\t "+row[1]+"\t\t\t "+row[2]+"\n")
                # closer the file
                lab51Table.close()
                break

            elif UserSave.lower() == "n":
                break
        break
    # check if the user select the enter key
    elif(not UserInput):

        # ask for a Name
        intID = intID + 1
        strName = input("please enter name: ")
        # ask for an Email
        strEmail = input ("please enter an email: ")
        # save the item and estimated value as a lstNewRow
        lstNewRow = [intID, strName,strEmail]
        # add the new row
        lstTable.append(lstNewRow)




