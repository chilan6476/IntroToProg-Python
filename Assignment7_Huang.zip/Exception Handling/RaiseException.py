# ---------------------------------------------------------------------------------------------#
# Title: Homework 7: Create a simple example of how you would use Python Exception Handling.
#                    Make sure to comment your code.
# Description: This provides an example of an AssertError exception for a user defined condition.
# Dev: Cindy Huang
# Date: 12/1/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#

# -- data code --#
intUsrSelection = None
strChoice = "Which option would you like to perform? [1-5] - "

# -- processing --#
def DisplayMenu():
    strMenu = "Menu of Options \n" \
              "1) Show current data" + "\n" \
              "2) Add a new item" + "\n" \
              "3) Remove an existing item" + "\n" \
              "4) Save Data to File" + "\n" \
              "5) Exit Program" + "\n"
    print(strMenu)

#-- Input/Output --#
# the code checks that user enters a specific selection. if the user selects an option outside
# of the range, an exception is raised.
DisplayMenu()
intUsrSelection = int(input(strChoice))

if intUsrSelection < 1 or intUsrSelection > 5:
    raise Exception ("The selection is {}, please select 1-5." .format(intUsrSelection))

