# ---------------------------------------------------------------------------------------------#
# Title: Homework 7: Create a simple example of how you would use Python Exception Handling.
#                    Make sure to comment your code.
# Description: This provides an example of an Try-Except.
# Dev: Cindy Huang
# Date: 12/1/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#


# -- data code --#
objFileName = "/Users/chilan6476/Documents/_PythonClass/Assignment07/ToDo.txt"

# -- processing --#
def ReadToDoFile(strFileName):
    objFile = open(strFileName, "r")
    # strData = A row of text data from the file
    strData = objFile.readlines()
    # lstTable = A dictionary that acts as a 'table' of rows (null to start with)
    lstTable = list()
    for i in strData:
        # dicRow = A row of data separated into elements of a dictionary {Task,Priority}
        dicRow = {"Task": i[0:i.find(",")], "Priority": i[i.find(",") + 1:-1]}
        lstTable.append(dicRow)
    return lstTable


#-- Input/Output --#
try:
    lstTable = ReadToDoFile(objFileName)

except FileNotFoundError as err: # check if the file exist.
    print ("\nToDo.txt is required. Please create a ToDo.txt before proceeding")

except Exception as err: # catch all exceptions.
    print (err)

