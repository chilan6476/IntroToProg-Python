# ---------------------------------------------------------------------------------------------#
# Title: Homework 7: Create a simple example of how you would use Python Exception Handling.
#                    Make sure to comment your code.
# Description: This provides an example of an AssertError exception for a user defined condition.
# Dev: Cindy Huang
# Date: 12/1/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#

from pathlib import Path

# -- data code --#
objFileName = Path("/Users/chilan6476/Documents/_PythonClass/Assignment07/ToDo.txt")

# -- processing --#
def ReadToDoFile(strFileName):
    objFile = open(strFileName, "r")
    # strData = A row of text data from the file
    strData = objFile.readlines()
    # lstTable = A dictionary that acts as a 'table' of rows (null to start with)
    lstTable = list()
    for i in strData:
        # dicRow = A row of data separated into elements of a dictionary {Task,Priority}
        dicRow = {"Task": i[0:i.find(",")], "Priority": i[i.find(",") + 1:-1]}
        lstTable.append(dicRow)
    return lstTable

#-- Input/Output --#
# the code checks if the ToDo.txt file exists before proceeding
assert objFileName.is_file(), "ToDo.txt must be created before running this program"
lstTable = ReadToDoFile(objFileName)





