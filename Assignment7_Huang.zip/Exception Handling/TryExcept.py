# ---------------------------------------------------------------------------------------------#
# Title: Homework 7: Create a simple example of how you would use Python Exception Handling.
#                    Make sure to comment your code.
# Description: This provides an example of an Try-Except.
# Dev: Cindy Huang
# Date: 12/1/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#


# -- data code --#
objFileName = "/Users/chilan6476/Documents/_PythonClass/Assignment07/ToDo.txt"
strChoice = "Which option would you like to perform? [1-5] - "
intUsrSelection = None

# -- processing --#
def ReadToDoFile(strFileName):
    objFile = open(strFileName, "r")
    # strData = A row of text data from the file
    strData = objFile.readlines()
    # lstTable = A dictionary that acts as a 'table' of rows (null to start with)
    lstTable = list()
    for i in strData:
        # dicRow = A row of data separated into elements of a dictionary {Task,Priority}
        dicRow = {"Task": i[0:i.find(",")], "Priority": i[i.find(",") + 1:-1]}
        lstTable.append(dicRow)
    return lstTable

def DisplayMenu():
    strMenu = "Menu of Options \n" \
              "1) Show current data" + "\n" \
              "2) Add a new item" + "\n" \
              "3) Remove an existing item" + "\n" \
              "4) Save Data to File" + "\n" \
              "5) Exit Program" + "\n"
    print(strMenu)

#-- Input/Output --#
try:
    lstTable = ReadToDoFile(objFileName)
    DisplayMenu()
    intUsrSelection = int(input(strChoice))
    # the code checks that user enters a specific selection. if the user selects an option outside
    # of the range, an exception is raised.
    if intUsrSelection < 1 or intUsrSelection > 5:
        raise Exception("The selection is {}, please select 1-5.".format(intUsrSelection))

except FileNotFoundError as err: # check if the file exist.
    print ("\nToDo.txt is required. Please create a ToDo.txt before proceeding")

except ValueError as err: # check if user input is not alphabets
    print("\nPlease enter only number between 1-5 for menu selection \n")


