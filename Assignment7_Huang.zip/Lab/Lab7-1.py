# ---------------------------------------------------------------------------------------------#
# Title: Lab7-1 Working with text files
# Description: 1)	Create a script that allows you to store product ids, names, and prices.
#                   The code will be very similar to the last example.
# Dev: Cindy Huang
# Date: 11/27/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#

# -- data code --#
FileName = "/Users/chilan6476/Documents/_PythonClass/Assignment07/ProductList.txt"
objFile = None
strUserInput = None


#-- Processing --#

# a function to continuously ask user for product to add unless user chooses to exit
def UpdateProductList(File):
    print("Type in a Product Id, Name and Prices you want to add to the file")
    print("(Enter 'Exit' to quit!)")
    while (True):
        strUserInput = input("Enter the Product Id, Name and Price (ex. 1, whiteboard, $20): ")
        if (strUserInput.lower() == "exit"):
            break
        else:
            File.write(strUserInput + "\n")

# read the entire file from the top
def ReadAllProductList(File):
    objFile.seek(0)
    print(File.read())

#-- Input/Output --#

objFile=open(FileName,"r+") # file must already exist.
ReadAllProductList(objFile)
UpdateProductList(objFile)
print("Here is this data was saved:")
ReadAllProductList(objFile)
objFile.close()

