# ---------------------------------------------------------------------------------------------#
# Title: Homework 7: 2)	Create a simple example of how you would use Python Pickling.
#                       Make sure to comment your code.
# Description: This provides an example of pickling function, dictionary, string and integer
# Dev: Cindy Huang
# Date: 12/1/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#
import pickle

# dictionary of data
dicRow1={"ID":1, "Name":"Bob Smith", "Email":"BSmith@Hotmail.com"}
dicRow2={"ID":2, "Name":"Sue Jones", "Email":"SueJ@Yahoo.com"}
dicRow3={"ID":3, "Name":"Joe James", "Email":"JoeJames@Gmail.com"}

# create a nested list for a table
lstTable=[dicRow1,dicRow2,dicRow3]
print(lstTable)

# picking the string and class/function
objFile = open("/Users/chilan6476/Documents/_PythonClass/Assignment07/Pickling/CustInfo.dat", "wb")
pickle.dump(dicRow1, objFile)
pickle.dump(dicRow2, objFile)
pickle.dump(dicRow3, objFile)
pickle.dump(lstTable, objFile)
objFile.close()



