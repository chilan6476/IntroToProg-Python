# ---------------------------------------------------------------------------------------------#
# Title: Homework 7: 2)	Create a simple example of how you would use Python Pickling.
#                       Make sure to comment your code.
# Description: This provides an example of unpickling function, dictionary, string and integer
# Dev: Cindy Huang
# Date: 12/1/2018
# Rev History: none
# ---------------------------------------------------------------------------------------------#
import pickle

objFile = open("/Users/chilan6476/Documents/_PythonClass/Assignment07/Pickling/CustInfo.dat","rb")
dictItem1 = pickle.load(objFile) #Note that load() only load one row of data.
print(dictItem1)
dictItem2 = pickle.load(objFile) #Note that load() only load one row of data.
print(dictItem2)
dictItem3 = pickle.load(objFile) #Note that load() only load one row of data.
print(dictItem3)
lstTable = pickle.load(objFile) #Note that load() only load one row of data.
print(lstTable)
objFile.close()


